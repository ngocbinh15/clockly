class AppSizes {
  static const double p4 = 4;
  static const double p8 = 8;
  static const double p12 = 12;
  static const double p16 = 16;
  static const double p24 = 24;
  static const double p32 = 32;
  static const double p40 = 40;

  static const double radius12 = 12;

  static const double iconMd = 24;
}